<?php
?>
<!-- jouw HTML met de inhoud over onderwerp 2 komt hier... -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Videogames</h1>
    <p>Videogames zijn een vorm van interactieve entertainment die wereldwijd enorm populair is. Ze omvatten een breed scala aan genres, van avonturen en puzzels tot actie en sport. Videogames worden gespeeld op verschillende platforms, zoals spelconsoles, pc's, smartphones en tablets.Een van de belangrijkste kenmerken van videogames is hun interactieve aard. Spelers nemen actieve rollen aan, maken keuzes en beïnvloeden de uitkomst van het spel. Dit onderscheidt videogames van passieve vormen van entertainment, zoals films en boeken. De meeslepende ervaringen die videogames bieden, worden versterkt door geavanceerde graphics, realistische geluidseffecten en complexe verhaallijnen.Videogames hebben niet alleen een amusementswaarde, maar bieden ook educatieve voordelen. Ze kunnen cognitieve vaardigheden verbeteren, zoals probleemoplossend vermogen, ruimtelijk inzicht en reactietijd. Bovendien bevorderen sommige games teamwork en strategisch denken, vooral in multiplayer-modus.De industrie achter videogames is enorm en blijft groeien. Jaarlijks worden er miljarden dollars gegenereerd door de verkoop van games, consoles en in-game aankopen. Deze groei wordt mede gedreven door de voortdurende technologische vooruitgang, zoals virtual reality en augmented reality, die nieuwe manieren van spelen mogelijk maken.Ondanks de vele voordelen zijn er ook zorgen over de invloed van videogames, zoals verslaving en gewelddadig gedrag. Het is daarom belangrijk dat spelers en ouders een gezonde balans vinden en bewust omgaan met de tijd die aan gamen wordt besteed.</p>
    <img class="menu__image" src="images/videogames.jpg" alt="php image">
</body>
</html>