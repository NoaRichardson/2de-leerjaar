<?php
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Stardew valley</h1>
    <p>Stardew Valley is een populaire indie-videogame ontwikkeld door Eric Barone, ook bekend als ConcernedApe. De game werd in februari 2016 uitgebracht en combineert elementen van simulatie en role-playing. In Stardew Valley nemen spelers de rol aan van een persoon die van de stad naar het platteland verhuist om de vervallen boerderij van hun grootvader op te knappen.Spelers beginnen met eenvoudige gereedschappen en een klein beetje geld. Het doel is om de boerderij weer tot leven te brengen door gewassen te verbouwen, dieren te verzorgen, mijnen te verkennen, en relaties op te bouwen met de dorpsbewoners. Elk seizoen biedt unieke uitdagingen en kansen, van het planten van seizoensgebonden gewassen tot het deelnemen aan dorpsfeesten.Een van de meest geliefde aspecten van Stardew Valley is de vrijheid en flexibiliteit die het spelers biedt. Men kan zich richten op landbouw, veeteelt, vissen, mijnbouw, of zelfs het verkennen van de diepe grotten en dungeons. De game bevat ook een sterke sociale component, waarbij spelers kunnen trouwen, een gezin stichten, en deel uitmaken van de lokale gemeenschap.Stardew Valley heeft lof ontvangen vanwege de charmante pixelart, de rustgevende muziek en de diepgaande gameplay. Het spel is beschikbaar op meerdere platforms, waaronder pc, consoles en mobiele apparaten, en heeft een grote en actieve fanbase. Dankzij regelmatige updates en mod-ondersteuning blijft Stardew Valley een tijdloze en geliefde titel in het genre van boerderijsimulatie.</p>
    <img class="menu__image" src="images/stardew-valley.jpg" alt="php image">
</body>
</html>