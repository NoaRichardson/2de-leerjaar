<?php
?>
<!-- jouw HTML met de inhoud over onderwerp 1 komt hier... -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Waterkringloop</h1>
    <p>De waterkringloop, ook wel hydrologische cyclus genoemd, is het proces waarbij water op aarde voortdurend circuleert tussen verschillende reservoirs. Deze cyclus begint met verdamping van water uit oceanen, meren en rivieren door de warmte van de zon. Waterdamp stijgt op en koelt af, waardoor condensatie plaatsvindt en wolken worden gevormd.Als de wolken verzadigd raken, valt het water terug naar de aarde in de vorm van neerslag, zoals regen, sneeuw of hagel. Een deel van deze neerslag infiltreert in de grond en wordt grondwater, dat langzaam door de bodem beweegt en uiteindelijk weer in rivieren, meren en oceanen terechtkomt. Het overige water stroomt als oppervlaktewater direct terug naar deze waterlichamen.Planten spelen ook een rol in de waterkringloop door middel van transpiratie, waarbij water via hun bladeren verdampt. Dit proces draagt bij aan de vochtigheid van de lucht en ondersteunt de condensatie.De waterkringloop is essentieel voor het leven op aarde. Het zorgt voor de verdeling van water over de planeet, reguleert klimaatpatronen en voorziet ecosystemen en menselijke samenlevingen van zoet water. De kringloop wordt beïnvloed door natuurlijke factoren, zoals klimaatverandering en menselijke activiteiten, waaronder landbouw, ontbossing en urbanisatie, die het natuurlijke evenwicht kunnen verstoren.</p>
    <img class="menu__image" src="images/waterkringloop.jpg" alt="php image">
</body>
</html>