﻿using System;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

class Arena
{
    public static int battleCount;
    public static int roundCount;

    public List<Trainer> createTrainer()
    {
        //Give trainers their name
        Battle battle = new Battle();
        List<String> trainerNames = new List<String>();
        for (int i = 1; i < 3; i++)
        {
            Console.WriteLine("Give a name to trainer" + i);
            String name = Console.ReadLine();
            trainerNames.Add(name);
        }
        List<Trainer> trainersClass = battle.createTrainerClass(trainerNames);
        return trainersClass;
    }

    public void startBattle(List<Trainer> trainersClass)
    {
        battleCount++;
        Battle battle = new Battle();
        battle.round(trainersClass);
    }

    public void startRound(int round)
    {
        roundCount++;
        Console.WriteLine("Round " + round);
    }

    public static int battleAmount()
    {
        return battleCount;
    }

    public static int roundAmount()
    {
        return roundCount;
    }
}