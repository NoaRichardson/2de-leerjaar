@extends("layouts.master")

@section("content")
<h1>Dit is de content van mijn begroetingspagina</h1>
<div class="container">
    <p>Dit is de bergroetingspagina! <br> Meer content komt later!</p>
</div>
@endsection
