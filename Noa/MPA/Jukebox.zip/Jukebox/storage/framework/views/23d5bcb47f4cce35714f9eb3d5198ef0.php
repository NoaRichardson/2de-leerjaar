<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/master.css">
    <?php echo $__env->yieldPushContent("styles"); ?>
</head>
<body>

<nav class="container">
    <ul class="menu">
        <a href="/login">Inloggen</a>
        <a href="/register">Registeren</a>
        <a href="/genres">Genres</a>
        <a href="/songs">Songs</a>
        <a href="/playlists">Playlists</a>
    </ul>
</nav>


<?php echo $__env->yieldContent("content"); ?>

 
<footer>Jukebox 2024</footer>


<?php echo $__env->yieldPushContent("js"); ?>
</body>
</html><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/layouts/master.blade.php ENDPATH**/ ?>