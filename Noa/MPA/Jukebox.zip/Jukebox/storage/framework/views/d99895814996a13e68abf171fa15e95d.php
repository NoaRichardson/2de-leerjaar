

<?php $__env->startSection("content"); ?>
    <div class="info_block">
        <h1>Name: <?php echo e($playlist->name); ?></h1>
        <p>Description: <?php echo e($playlist->description); ?></p>
        <p>Playlist songs:</p>
        <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            -<?php echo e($song->name); ?>

            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p>Playlist Duration: <?php echo e($playlistDuration); ?></p>

        <form action="/playlist/addsong/<?php echo e($playlist->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <select name="selectedSong">
                <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($song->id); ?>"><?php echo e($song->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="submit" value="Add to playlist">
        </form>
    </div>
    <a href="/playlist/edit/<?php echo e($playlist->id); ?>">Edit Playlist</a>
    <form action="/playlist/delete/<?php echo e($playlist->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <select name="selectedSong">
                <?php $__currentLoopData = $playlistSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($song->id); ?>"><?php echo e($song->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="submit" value="Delete from playlist">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/playlists/show.blade.php ENDPATH**/ ?>