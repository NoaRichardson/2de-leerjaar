

<?php $__env->startSection("content"); ?>
    <h1>Hier is een lijst met de genres</h1>
    <ul class="container">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($genre->name); ?> - <?php echo e($genre->songs->count()); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/songs/genres.blade.php ENDPATH**/ ?>