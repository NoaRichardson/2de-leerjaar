

<?php $__env->startSection("content"); ?>
    <h1>Hier is een lijst met de genres</h1>
    <ul class="container">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/genre/view/<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/genres/index.blade.php ENDPATH**/ ?>