

<?php $__env->startSection("content"); ?>
    <h1>Hier zie je jouw playlists</h1>
    <ul class="container">
        <?php if(Auth::check()): ?>
            <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/playlist/view/<?php echo e($playlist->id); ?>"><?php echo e($playlist->name); ?></a>
                </li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php if(session('temporary_playlists')): ?>
                <?php $__currentLoopData = session('temporary_playlists'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporaryPlaylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span><?php echo e($temporaryPlaylist['name']); ?></span> (Temporary)
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/playlists/index.blade.php ENDPATH**/ ?>