

<?php $__env->startSection("content"); ?>
<h1>Dit is de content van mijn begroetingspagina</h1>
<div class="container">
    <p>Dit is de bergroetingspagina! <br> Meer content komt later!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/hello.blade.php ENDPATH**/ ?>