

<!-- get id of song and then ask the model to pick their data up -->
<?php $__env->startSection("content"); ?>
    <h1>Song details</h1>
    <a href="/songs">terug</a>
    <ul class="container">
        //
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/songs/song-detail.blade.php ENDPATH**/ ?>