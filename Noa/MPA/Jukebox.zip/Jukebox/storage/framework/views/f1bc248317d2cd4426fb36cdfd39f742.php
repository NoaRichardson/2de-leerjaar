

<?php $__env->startSection("content"); ?>
    <div class="info_block">
        <h1>Name: <?php echo e($song->name); ?></h1>
        <p>Duration: <?php echo e($song->duration); ?></p>
        <p>Artist: <?php echo e($song->artist); ?></p>

        <?php if(Auth::check()): ?>
            <form action="/song/addplaylist/<?php echo e($song->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <select name="selectedPlaylist">
                    <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($playlist->id); ?>"><?php echo e($playlist->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="submit" value="Add to playlist">
            </form>
        <?php else: ?>
            <?php if(session('temporary_playlists')): ?>
                <form action="/song/addplaylist/<?php echo e($song->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <select name="selectedPlaylist">
                        <?php $__currentLoopData = session('temporary_playlists'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporaryPlaylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($temporaryPlaylist['name']); ?>"><?php echo e($temporaryPlaylist['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" value="Add to temporary playlist">
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/songs/detail.blade.php ENDPATH**/ ?>