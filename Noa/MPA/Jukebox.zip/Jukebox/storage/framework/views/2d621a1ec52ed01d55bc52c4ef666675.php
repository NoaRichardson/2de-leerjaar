

<?php $__env->startSection("content"); ?>
<div class="info_block">
    <h1><?php echo e($genre->name); ?></h1>
    <p>Er zijn <?php echo e($genre->songs->count()); ?> liedjes met deze genre</p>
    <?php $__currentLoopData = $genre->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($song->name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noa73\2de leerjaar\opdracht-bovenbouw\Noa\MPA\Jukebox\resources\views/genres/detail.blade.php ENDPATH**/ ?>